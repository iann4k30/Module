#!/sbin/sh

MODDIR=${0%/*}

# Load the selected mode
MODE=$(cat $MODDIR/mode 2>/dev/null || echo "performance")

# Apply CPU settings based on mode
apply_cpu_settings() {
    # Paths to CPU control files (may vary per device)
    CPU_DIR="/sys/devices/system/cpu"
    
    # Enable all CPU cores
    for cpu in $(seq 0 7); do
        if [ -d "$CPU_DIR/cpu$cpu" ]; then
            echo 1 > "$CPU_DIR/cpu$cpu/online"
        fi
    done

    # Set governor to performance
    for cpu in $(seq 0 7); do
        if [ -d "$CPU_DIR/cpu$cpu/cpufreq" ]; then
            echo "performance" > "$CPU_DIR/cpu$cpu/cpufreq/scaling_governor"
        fi
    done

    # Set max frequency based on mode
    if [ "$MODE" = "extreme" ]; then
        # Extreme mode - push to absolute max
        for cpu in $(seq 0 7); do
            if [ -d "$CPU_DIR/cpu$cpu/cpufreq" ]; then
                MAX_FREQ=$(cat "$CPU_DIR/cpu$cpu/cpufreq/cpuinfo_max_freq")
                echo $MAX_FREQ > "$CPU_DIR/cpu$cpu/cpufreq/scaling_max_freq"
                echo $MAX_FREQ > "$CPU_DIR/cpu$cpu/cpufreq/scaling_min_freq"
            fi
        done
        
        # Increase thermal thresholds (if available)
        if [ -f "/sys/module/msm_thermal/parameters/temp_threshold" ]; then
            echo 100 > /sys/module/msm_thermal/parameters/temp_threshold
        fi
    else
        # Performance mode - balanced approach
        for cpu in $(seq 0 7); do
            if [ -d "$CPU_DIR/cpu$cpu/cpufreq" ]; then
                MAX_FREQ=$(cat "$CPU_DIR/cpu$cpu/cpufreq/cpuinfo_max_freq")
                BALANCED_FREQ=$((MAX_FREQ * 90 / 100)) # 90% of max freq
                echo $MAX_FREQ > "$CPU_DIR/cpu$cpu/cpufreq/scaling_max_freq"
                echo $BALANCED_FREQ > "$CPU_DIR/cpu$cpu/cpufreq/scaling_min_freq"
            fi
        done
    fi
    
    # Disable CPU boost limitations
    if [ -f "/sys/module/cpu_boost/parameters/input_boost_freq" ]; then
        echo "0" > /sys/module/cpu_boost/parameters/input_boost_freq
    fi
    
    if [ -f "/sys/module/cpu_boost/parameters/input_boost_ms" ]; then
        echo "0" > /sys/module/cpu_boost/parameters/input_boost_ms
    fi
}

apply_cpu_settings

exit 0