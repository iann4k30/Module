#!/sbin/sh

# This script runs in the background after boot

# Load the selected mode
MODDIR=${0%/*}
MODE=$(cat $MODDIR/mode 2>/dev/null || echo "performance")

# Monitor and re-apply settings periodically
while true; do
    apply_cpu_settings
    sleep 60
done