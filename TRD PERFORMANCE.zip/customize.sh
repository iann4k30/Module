#!/sbin/sh

MODDIR=${0%/*}
KEYCHECK=$MODDIR/tools/keycheck

ui_print " "
ui_print "*******************************"
ui_print "*TRD Performance*"
ui_print "*******************************"
ui_print " "
ui-print "Boost Lebih, Panas Nggak Lebih Cuma di TRD"

# Save the selected mode
echo "$MODE" > $MODDIR/mode

ui_print " "
ui_print "Instalasi selesai!"
ui_print "Reboot perangkat untuk menerapkan pengaturan"
ui_print " "